/* Z Sphere - Public Sessions Catalogue & Database Filtering */

document.addEventListener('DOMContentLoaded', function () {
    const sessionsContainer = document.getElementById('sessions-list-container');
    const featuredContainer = document.getElementById('featured-sessions-container');
    const searchInput = document.getElementById('sessions-search-input');
    const statusSelect = document.getElementById('filter-status');
    const typeSelect = document.getElementById('filter-type');
    const modeSelect = document.getElementById('filter-mode');
    const clearFiltersBtn = document.getElementById('clear-filters-btn');
    const resultCountEl = document.getElementById('sessions-result-count');

    // Helper to render an event card with Supabase media URL resolution
    function renderEventCard(evt) {
        const isPages = window.ZSphereApp ? window.ZSphereApp.isPagesDir() : false;
        const safeSlug = encodeURIComponent(evt.slug || '');
        const detailLink = isPages ? `event.html?slug=${safeSlug}` : `pages/event.html?slug=${safeSlug}`;

        let displayStatus = evt.status || 'upcoming';
        
        if ((displayStatus === 'published' || displayStatus === 'upcoming') && evt.end_at) {
            if (new Date(evt.end_at) < new Date()) {
                displayStatus = 'completed';
            }
        }

        let statusBadgeClass = 'badge-completed';
        if (displayStatus === 'upcoming' || displayStatus === 'published') statusBadgeClass = 'badge-open';
        if (displayStatus === 'full') statusBadgeClass = 'badge-full';

        const isOnline = evt.venue && (evt.venue.toLowerCase().includes('online') || evt.venue.toLowerCase().includes('meet'));
        let modeBadgeClass = isOnline ? 'badge-online' : 'badge-in-person';
        const modeLabel = isOnline ? 'ONLINE' : 'IN-PERSON';

        const dateDisplay = evt.start_at ? window.ZSphereApp.formatDate(evt.start_at) : 'TBA';
        const fallbackBanner = window.ZSphereApp.getDefaultBanner(evt);
        const coverUrl = evt.cover_path ? window.ZSphereDataService.getPublicMediaUrl(evt.cover_path) : fallbackBanner;

        return `
            <article class="event-card">
                <div class="event-card-img-wrap">
                    <img src="${coverUrl}" alt="${window.ZSphereApp.escapeHtml(evt.title)}" class="event-card-img" loading="lazy" data-fallback-src="${fallbackBanner}">
                </div>
                <div class="event-card-body">
                    <div class="event-card-meta">
                        <span class="badge ${modeBadgeClass}">${modeLabel}</span>
                        <span class="badge ${statusBadgeClass}">${(displayStatus || 'UPCOMING').toUpperCase()}</span>
                        <span class="tag">${window.ZSphereApp.escapeHtml(evt.category || 'General')}</span>
                    </div>
                    <h3 class="event-card-title">
                        <a href="${detailLink}">${window.ZSphereApp.escapeHtml(evt.title)}</a>
                    </h3>
                    <div class="event-card-details">
                        <span class="d-inline-flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> ${dateDisplay}</span>
                        <span class="d-inline-flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg> ${window.ZSphereApp.escapeHtml(evt.venue || 'TBA')}</span>
                    </div>
                    <p class="event-card-desc">${window.ZSphereApp.escapeHtml(evt.summary || '')}</p>
                    <div class="event-card-foot">
                        <span class="event-author">${evt.conducted_by ? 'Facilitated by ' + window.ZSphereApp.escapeHtml(evt.conducted_by) : ''}</span>
                        <a href="${detailLink}" class="btn btn-primary btn-sm">View Session Details &rarr;</a>
                    </div>
                </div>
            </article>
        `;
    }

    // Load Featured Events on Landing Page
    async function loadFeaturedEvents() {
        if (!featuredContainer || !window.ZSphereDataService) return;
        if (window.ZSphereUI) window.ZSphereUI.renderLoadingSkeleton(featuredContainer, 2, 'card');

        try {
            const featured = await window.ZSphereDataService.getFeaturedEvents();
            if (featured.length === 0) {
                if (window.ZSphereUI) {
                    window.ZSphereUI.renderEmptyState(featuredContainer, 'No upcoming featured sessions', 'Check back soon for new workshop announcements.');
                }
            } else {
                featuredContainer.innerHTML = featured.map(renderEventCard).join('');
            }
        } catch (e) {
            console.error('Error loading featured events:', e);
            if (window.ZSphereUI) {
                window.ZSphereUI.renderErrorState(featuredContainer, 'Unable to load featured sessions', 'Please check your connection and try again.', loadFeaturedEvents);
            }
        }
    }

    // Sessions Catalogue Filtering
    async function fetchAndRenderSessions() {
        if (!sessionsContainer || !window.ZSphereDataService) return;
        if (window.ZSphereUI) window.ZSphereUI.renderLoadingSkeleton(sessionsContainer, 3, 'card');

        const query = searchInput ? searchInput.value.trim() : '';
        const status = statusSelect ? statusSelect.value : 'all';
        const type = typeSelect ? typeSelect.value : 'all';
        const mode = modeSelect ? modeSelect.value : 'all';

        try {
            const events = await window.ZSphereDataService.getEvents({
                q: query,
                status: status,
                type: type,
                mode: mode
            });

            if (resultCountEl) {
                resultCountEl.textContent = `${events.length} session${events.length !== 1 ? 's' : ''} available`;
            }

            if (events.length === 0) {
                if (window.ZSphereUI) {
                    window.ZSphereUI.renderEmptyState(
                        sessionsContainer,
                        'No sessions match your search',
                        'Try resetting your status or category filters to explore all available sessions.',
                        'Reset All Filters',
                        null,
                        window.ZSphereSessionsClearFilters
                    );
                }
            } else {
                sessionsContainer.innerHTML = events.map(renderEventCard).join('');
            }
        } catch (err) {
            console.error('Error fetching sessions:', err);
            if (window.ZSphereUI) {
                window.ZSphereUI.renderErrorState(sessionsContainer, 'Could not load sessions', 'Failed to fetch sessions catalogue from database.', fetchAndRenderSessions);
            }
        }
    }

    window.ZSphereSessionsClearFilters = function () {
        if (searchInput) searchInput.value = '';
        if (statusSelect) statusSelect.value = 'all';
        if (typeSelect) typeSelect.value = 'all';
        if (modeSelect) modeSelect.value = 'all';
        fetchAndRenderSessions();
    };

    // Event listeners
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(fetchAndRenderSessions, 250);
        });
    }
    if (statusSelect) statusSelect.addEventListener('change', fetchAndRenderSessions);
    if (typeSelect) typeSelect.addEventListener('change', fetchAndRenderSessions);
    if (modeSelect) modeSelect.addEventListener('change', fetchAndRenderSessions);
    if (clearFiltersBtn) clearFiltersBtn.addEventListener('click', window.ZSphereSessionsClearFilters);

    // URL parameter pre-fill
    if (searchInput && window.ZSphereApp) {
        const urlQ = window.ZSphereApp.getParam('q');
        if (urlQ) searchInput.value = urlQ;
    }
    
    // Load Recent Albums (for index2.html)
    async function loadRecentAlbums() {
        const homeGalleryContainer = document.getElementById('home-gallery-container');
        if (!homeGalleryContainer) return;
        
        try {
            let albums = [];
            if (window.ZSphereDataService && typeof window.ZSphereDataService.getGalleryAlbums === 'function') {
                try {
                    albums = await window.ZSphereDataService.getGalleryAlbums();
                } catch (err) {
                    console.warn('Error fetching home albums:', err);
                }
            }
            
            if (!albums || albums.length === 0) {
                if (window.ZSphereDataService && typeof window.ZSphereDataService.getDefaultAlbums === 'function') {
                    albums = window.ZSphereDataService.getDefaultAlbums();
                }
            }
            
            if (!albums || albums.length === 0) return;
            
            const recentAlbums = albums.slice(0, 3);
            const isPages = window.ZSphereApp ? window.ZSphereApp.isPagesDir() : false;
            
            homeGalleryContainer.innerHTML = recentAlbums.map((alb, idx) => {
                const dateDisplay = alb.created_at ? (window.ZSphereApp ? window.ZSphereApp.formatDate(alb.created_at) : '') : '';
                const coverUrl = (alb.cover_path && window.ZSphereDataService) ? window.ZSphereDataService.getPublicMediaUrl(alb.cover_path) : null;
                const initials = alb.title ? alb.title.substring(0, 2).toUpperCase() : 'ZS';
                const safeAlbumSlug = encodeURIComponent(alb.slug || alb.id || '');
                const detailLink = isPages ? `gallery-album.html?album=${safeAlbumSlug}` : `pages/gallery-album.html?album=${safeAlbumSlug}`;
                const trackName = alb.events && alb.events.title ? (window.ZSphereApp ? window.ZSphereApp.escapeHtml(alb.events.title) : alb.events.title) : 'Technical Workshop';

                return `
                    <div class="album-card reveal reveal-delay-${idx}">
                        <div class="album-cover">
                            ${coverUrl ? `<img src="${coverUrl}" alt="${window.ZSphereApp ? window.ZSphereApp.escapeHtml(alb.title) : alb.title}" loading="lazy" data-fallback-text="${initials}">` : `
                                <div class="album-cover-initials">${initials}</div>
                                <span class="album-cover-badge">${trackName}</span>
                            `}
                        </div>
                        <div class="album-info">
                            <span class="text-muted text-xs d-block mb-1">${dateDisplay} · ${trackName}</span>
                            <h3 class="card-title mb-2">${window.ZSphereApp ? window.ZSphereApp.escapeHtml(alb.title) : alb.title}</h3>
                            <a href="${detailLink}" class="btn btn-ghost btn-sm mt-1">View Album &rarr;</a>
                        </div>
                    </div>
                `;
            }).join('');

            if (window.ZSphereUI && typeof window.ZSphereUI.initRevealObserver === 'function') {
                window.ZSphereUI.initRevealObserver();
            }
        } catch (err) {
            console.error('Error fetching home albums:', err);
        }
    }

    // Initialize queries
    loadFeaturedEvents();
    fetchAndRenderSessions();
    loadRecentAlbums();
});
