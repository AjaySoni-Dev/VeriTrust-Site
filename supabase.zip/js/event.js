/* Z Sphere - Event Detail, Lifecycle & Registration Controller */

document.addEventListener('DOMContentLoaded', async function () {
    const detailContainer = document.getElementById('event-detail-container');
    if (!detailContainer || !window.ZSphereDataService) return;

    const slug = window.ZSphereApp.getParam('slug');
    if (!slug) {
        if (window.ZSphereUI) {
            window.ZSphereUI.renderEmptyState(detailContainer, 'No session selected', 'Please select a session from the catalogue to view details.', 'Browse Sessions', 'sessions.html');
        }
        return;
    }

    if (window.ZSphereUI) {
        window.ZSphereUI.renderLoadingSkeleton(detailContainer, 1, 'card');
    }

    // Helper to generate Google Calendar link
    function getGoogleCalendarUrl(evt) {
        if (!evt || !evt.start_at) return '#';
        const title = encodeURIComponent(evt.title || 'Z Sphere Workshop');
        const details = encodeURIComponent((evt.summary || evt.description || '') + '\n\nOrganized by Z Sphere');
        const location = encodeURIComponent(evt.venue || 'Online / Campus');
        
        const startDate = new Date(evt.start_at);
        const endDate = new Date(startDate.getTime() + (2 * 60 * 60 * 1000)); // Default 2h duration
        
        const formatCalDate = (d) => d.toISOString().replace(/-|:|\.\d+/g, '');
        const dates = `${formatCalDate(startDate)}/${formatCalDate(endDate)}`;
        
        return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${dates}&details=${details}&location=${location}`;
    }

    // Helper to download .ics calendar event
    function downloadIcsFile(evt) {
        if (!evt || !evt.start_at) return;
        const startDate = new Date(evt.start_at);
        const endDate = new Date(startDate.getTime() + (2 * 60 * 60 * 1000));
        const formatIcs = (d) => d.toISOString().replace(/-|:|\.\d+/g, '');

        const icsContent = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Z Sphere//Student Events//EN',
            'BEGIN:VEVENT',
            `UID:zsphere-${evt.id || Date.now()}@zsphere.org`,
            `DTSTAMP:${formatIcs(new Date())}`,
            `DTSTART:${formatIcs(startDate)}`,
            `DTEND:${formatIcs(endDate)}`,
            `SUMMARY:${evt.title || 'Z Sphere Session'}`,
            `DESCRIPTION:${(evt.summary || evt.description || '').replace(/\n/g, '\\n')}`,
            `LOCATION:${evt.venue || 'Campus / Online'}`,
            'STATUS:CONFIRMED',
            'END:VEVENT',
            'END:VCALENDAR'
        ].join('\r\n');

        const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', `${evt.slug || 'session'}-calendar.ics`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    async function loadEventPage() {
        try {
            // Public details are intentionally available without authentication. Auth is only
            // consulted to decide whether sensitive registration links may be requested.
            const authReady = (window.ZSphereAuth && typeof window.ZSphereAuth.waitUntilReady === 'function')
                ? window.ZSphereAuth.waitUntilReady()
                : Promise.resolve();

            let evt = await window.ZSphereDataService.getPublicEventBySlug(slug, false);
            await authReady;

            const isSignedIn = Boolean(window.ZSphereAuthState && window.ZSphereAuthState.user);
            if (evt && isSignedIn) {
                const authenticatedEvent = await window.ZSphereDataService.getPublicEventBySlug(slug, true);
                if (authenticatedEvent) evt = authenticatedEvent;
            }

            if (!evt) {
                if (window.ZSphereUI) {
                    window.ZSphereUI.renderEmptyState(detailContainer, 'Session Not Found', 'The session you are looking for does not exist or has been archived.', 'Back to Sessions', 'sessions.html');
                }
                return;
            }

            document.title = `${evt.title} — Z Sphere`;

            const fallbackBanner = window.ZSphereApp.getDefaultBanner(evt);
            const coverUrl = evt.cover_path ? window.ZSphereDataService.getPublicMediaUrl(evt.cover_path) : fallbackBanner;
            const isOnline = evt.venue && (evt.venue.toLowerCase().includes('online') || evt.venue.toLowerCase().includes('meet'));
            const dateDisplay = evt.start_at ? window.ZSphereApp.formatDate(evt.start_at) : 'TBA';

            // Calculate Seats & Availability
            const registeredCount = evt.registered_count || 0;
            const capacity = evt.capacity || 0;
            const seatsLeft = capacity ? capacity - registeredCount : '∞';
            
            let isRegOpen = false;
            if (evt.status === 'published') {
                const now = new Date();
                const opensAt = evt.registration_opens_at ? new Date(evt.registration_opens_at) : null;
                const closesAt = evt.registration_closes_at ? new Date(evt.registration_closes_at) : null;
                if ((!opensAt || opensAt <= now) && (!closesAt || closesAt > now)) {
                    isRegOpen = true;
                }
            }
            
            const pctFilled = capacity ? Math.min(100, Math.round((registeredCount / capacity) * 100)) : 0;
            const fillMeterClass = pctFilled >= 90 ? 'danger' : (pctFilled >= 70 ? 'warning' : '');

            const learningPoints = Array.isArray(evt.learning_points) ? evt.learning_points : [];
            const agenda = Array.isArray(evt.agenda) ? evt.agenda : [];
            const resources = Array.isArray(evt.resources) ? evt.resources : [];

            // Determine Registration State & Action Buttons
            let regButtonHtml = '';

            if (evt.status === 'completed') {
                regButtonHtml = `<button class="btn btn-secondary btn-full" disabled>Session Completed</button>`;
            } else if (capacity > 0 && seatsLeft <= 0) {
                regButtonHtml = `<button class="btn btn-secondary btn-full" disabled>Session Full (${capacity}/${capacity} Seats)</button>`;
            } else if (!isRegOpen) {
                regButtonHtml = `<button class="btn btn-secondary btn-full" disabled>Registration Closed</button>`;
            } else if (!isSignedIn) {
                regButtonHtml = `
                    <a href="login.html" class="btn btn-primary btn-full" data-registration-login>Sign In to Register</a>
                    <p class="text-muted text-xs text-center mt-2 mb-0">Session details stay public. An account is required only when you register.</p>
                `;
            } else if (evt.registration_form_url) {
                regButtonHtml = `
                    <a href="${window.ZSphereApp.sanitizeUrl(evt.registration_form_url)}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-full">Register for this Session</a>
                `;
            } else {
                regButtonHtml = `<button class="btn btn-secondary btn-full" disabled>Registration Not Available</button>`;
            }

            if (isSignedIn && evt.whatsapp_group_url) {
                regButtonHtml += `
                    <div class="mt-2">
                        <a href="${window.ZSphereApp.sanitizeUrl(evt.whatsapp_group_url)}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-full">Join WhatsApp Group</a>
                    </div>
                `;
            }
            
            regButtonHtml += `
                <div class="calendar-action-wrap d-flex gap-2 justify-center flex-wrap mt-3">
                    <a href="${getGoogleCalendarUrl(evt)}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm d-inline-flex items-center gap-1">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <span>Google Calendar</span>
                    </a>
                    <button type="button" class="btn btn-secondary btn-sm d-inline-flex items-center gap-1" id="download-ics-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        <span>Download iCal (.ics)</span>
                    </button>
                </div>
            `;

            detailContainer.innerHTML = `
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <span class="breadcrumb-item"><a href="../index2.html">Home</a></span>
                    <span class="breadcrumb-separator">/</span>
                    <span class="breadcrumb-item"><a href="sessions.html">Sessions</a></span>
                    <span class="breadcrumb-separator">/</span>
                    <span class="breadcrumb-item" aria-current="page">${window.ZSphereApp.escapeHtml(evt.title)}</span>
                </nav>

                <div class="event-hero-banner">
                    <img src="${coverUrl}" alt="${window.ZSphereApp.escapeHtml(evt.title)}" class="event-hero-cover" data-fallback-src="${fallbackBanner}">
                </div>

                <div class="event-detail-grid">
                    <div class="event-main-content">
                        <div class="tag-list mb-3">
                            <span class="badge ${isOnline ? 'badge-online' : 'badge-in-person'}">${isOnline ? 'ONLINE' : 'IN-PERSON'}</span>
                            <span class="badge badge-workshop">${(evt.event_type || 'workshop').toUpperCase()}</span>
                            <span class="tag">${window.ZSphereApp.escapeHtml(evt.category || 'General')}</span>
                        </div>

                        <h1 class="page-title mb-3">${window.ZSphereApp.escapeHtml(evt.title)}</h1>

                        <p class="body-text mb-4 text-base">${window.ZSphereApp.escapeHtml(evt.description || evt.summary || '')}</p>

                        ${learningPoints.length > 0 ? `
                            <div class="event-section">
                                <h2 class="event-section-title">What You'll Learn</h2>
                                <ul class="learning-points-list">
                                    ${learningPoints.map(pt => `
                                        <li class="learning-point-item">
                                            <span class="point-check" aria-hidden="true"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                                            <span>${window.ZSphereApp.escapeHtml(typeof pt === 'string' ? pt : pt.title || '')}</span>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                        ` : ''}

                        ${agenda.length > 0 ? `
                            <div class="event-section">
                                <h2 class="event-section-title">Session Agenda & Schedule</h2>
                                <div class="agenda-list">
                                    ${agenda.map(item => `
                                        <div class="agenda-item">
                                            <div class="agenda-time">${window.ZSphereApp.escapeHtml(item.time || item.start || '')}</div>
                                            <div class="agenda-title">${window.ZSphereApp.escapeHtml(item.title || '')}</div>
                                            <div class="agenda-desc">${window.ZSphereApp.escapeHtml(item.desc || item.description || '')}</div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <div class="event-section">
                            <h2 class="event-section-title">Session Facilitator</h2>
                            <div class="card-bordered d-flex items-center gap-4">
                                <div class="avatar-circle avatar-lg avatar-hero flex-center flex-shrink-0">
                                    ${evt.conducted_by ? evt.conducted_by.substring(0, 2).toUpperCase() : 'ZS'}
                                </div>
                                <div>
                                    <h3 class="card-title mb-1">${window.ZSphereApp.escapeHtml(evt.conducted_by || 'Z Sphere Team Lead')}</h3>
                                    <div class="text-muted text-sm">Technical Workshop Facilitator · ${window.ZSphereApp.escapeHtml(evt.category || 'Z Sphere Community')}</div>
                                </div>
                            </div>
                        </div>

                        ${resources.length > 0 ? `
                            <div class="event-section">
                                <h2 class="event-section-title">Workshop Resources & Code Files</h2>
                                <ul class="resources-list">
                                    ${resources.map(res => `
                                        <li>
                                            <a href="${window.ZSphereApp.sanitizeUrl(res.url)}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm d-inline-flex items-center gap-1">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                                                <span>${window.ZSphereApp.escapeHtml(res.label || res.title || 'Session Resource Link')}</span>
                                                <span>&rarr;</span>
                                            </a>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                        ` : ''}

                        <div id="event-gallery-container"></div>
                    </div>

                    <div class="event-sidebar">
                        <aside class="registration-card" aria-label="Session Registration Overview">
                            <h3 class="card-title mb-3">Session Overview</h3>

                            <div class="reg-card-row">
                                <div>
                                    <strong class="d-block text-navy">Date & Time</strong>
                                    <span class="text-muted text-sm d-inline-flex items-center gap-1">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                        <span>${dateDisplay}</span>
                                    </span>
                                </div>
                            </div>

                            <div class="reg-card-row">
                                <div>
                                    <strong class="d-block text-navy">Venue / Format</strong>
                                    <span class="text-muted text-sm d-inline-flex items-center gap-1">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                        <span>${window.ZSphereApp.escapeHtml(evt.venue || 'TBA')}</span>
                                    </span>
                                </div>
                            </div>

                            <div class="reg-card-row">
                                <div>
                                    <strong class="d-block text-navy">Facilitator</strong>
                                    <span class="text-muted text-sm d-inline-flex items-center gap-1">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                        <span>${window.ZSphereApp.escapeHtml(evt.conducted_by || 'Z Sphere Team')}</span>
                                    </span>
                                </div>
                            </div>

                            <div class="reg-card-row">
                                <div class="w-full">
                                    <div class="seat-meter-header">
                                        <span>Seat Availability</span>
                                        <span>${registeredCount} / ${capacity || '∞'} Seats</span>
                                    </div>
                                    ${capacity > 0 ? `
                                        <div class="seat-meter-bar">
                                            <div class="seat-meter-fill ${fillMeterClass}" style="width: ${pctFilled}%;"></div>
                                        </div>
                                        <span class="text-muted text-xs d-block mt-1">${seatsLeft > 0 ? seatsLeft + ' seats remaining' : 'Fully booked'}</span>
                                    ` : `
                                        <span class="text-muted text-xs">Open registration</span>
                                    `}
                                </div>
                            </div>

                            <div class="mt-4" id="reg-action-area">
                                ${regButtonHtml}
                            </div>
                        </aside>
                    </div>
                </div>
            `;

            // Attach ics download listener
            const icsBtn = document.getElementById('download-ics-btn');
            if (icsBtn) {
                icsBtn.addEventListener('click', () => downloadIcsFile(evt));
            }

            const registrationLogin = detailContainer.querySelector('[data-registration-login]');
            if (registrationLogin) {
                registrationLogin.addEventListener('click', function () {
                    try {
                        sessionStorage.setItem('zsphere_redirect_after_login', `event.html?slug=${encodeURIComponent(slug)}`);
                    } catch (e) {}
                });
            }

            // Load associated gallery album if exists
            const galleryContainer = document.getElementById('event-gallery-container');
            if (galleryContainer && evt.id) {
                const album = await window.ZSphereDataService.getGalleryAlbumByEventId(evt.id);
                if (album) {
                    const images = await window.ZSphereDataService.getGalleryImages(album.id);
                    if (images && images.length > 0) {
                        const isPages = window.ZSphereApp ? window.ZSphereApp.isPagesDir() : false;
                        const safeAlbumSlug = encodeURIComponent(album.slug || '');
                        const albumLink = isPages ? `gallery-album.html?album=${safeAlbumSlug}` : `pages/gallery-album.html?album=${safeAlbumSlug}`;
                        
                        galleryContainer.innerHTML = `
                            <div class="event-section mt-5">
                                <div class="d-flex justify-between items-center mb-3">
                                    <h2 class="event-section-title mb-0">Session Photo Gallery</h2>
                                    <a href="${albumLink}" class="btn btn-ghost btn-sm">View Full Album &rarr;</a>
                                </div>
                                <div class="photo-grid">
                                    ${images.slice(0, 6).map((img) => {
                                        const imgUrl = img.storage_path ? window.ZSphereDataService.getPublicMediaUrl(img.storage_path) : '';
                                        return `
                                            <div class="photo-item">
                                                ${imgUrl ? `<img src="${imgUrl}" alt="${window.ZSphereApp.escapeHtml(img.alt_text || album.title)}" loading="lazy">` : ''}
                                            </div>
                                        `;
                                    }).join('')}
                                </div>
                                ${images.length > 6 ? `<p class="text-center mt-2"><a href="${albumLink}" class="text-sm">View all ${images.length} photos</a></p>` : ''}
                            </div>
                        `;
                    }
                }
            }

        } catch (err) {
            console.error('Error loading event detail:', err);
            if (window.ZSphereUI) {
                window.ZSphereUI.renderErrorState(detailContainer, 'Could not load session details', 'Please check your internet connection and try again.', loadEventPage);
            }
        }
    }

    loadEventPage();
});
