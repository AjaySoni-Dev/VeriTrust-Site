/* Z Sphere - Student Account, Profile & Registered Sessions Controller */

document.addEventListener('DOMContentLoaded', async function () {
    // 1. Guard protected account pages
    if (window.ZSphereAuth) {
        const isAuth = await window.ZSphereAuth.requireAuthAsync();
        if (!isAuth) return;
    }

    // Helper to update sidebar user info
    function populateSidebarUser() {
        const profile = window.ZSphereAuthState ? window.ZSphereAuthState.profile : null;
        const user = window.ZSphereAuthState ? window.ZSphereAuthState.user : null;

        const nameEls = document.querySelectorAll('.account-user-name');
        const emailEls = document.querySelectorAll('.account-user-email');
        const avatarEls = document.querySelectorAll('.account-user-avatar');

        const fullName = (profile && profile.full_name) || (user && user.user_metadata && user.user_metadata.full_name) || 'Student User';
        const email = (user && user.email) || (profile && profile.email) || '';
        const initials = fullName ? fullName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'SU';

        nameEls.forEach(el => el.textContent = fullName);
        emailEls.forEach(el => el.textContent = email);
        avatarEls.forEach(el => el.textContent = initials);
    }

    // 2. Profile Editing Form (profile.html)
    const profileForm = document.getElementById('profile-edit-form');
    if (profileForm) {
        const nameInput = document.getElementById('profile-name');
        const emailInput = document.getElementById('profile-email');
        const courseInput = document.getElementById('profile-course');
        const semInput = document.getElementById('profile-semester');

        async function loadProfileForm() {
            populateSidebarUser();
            const profile = window.ZSphereAuthState ? window.ZSphereAuthState.profile : null;
            const user = window.ZSphereAuthState ? window.ZSphereAuthState.user : null;

            if (nameInput) nameInput.value = (profile && profile.full_name) || (user && user.user_metadata && user.user_metadata.full_name) || '';
            if (emailInput) emailInput.value = (user && user.email) || (profile && profile.email) || '';
            if (courseInput) courseInput.value = (profile && profile.course) || '';
            if (semInput) semInput.value = (profile && profile.semester) || '';
        }

        profileForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const submitBtn = profileForm.querySelector('button[type="submit"]');

            if (!nameInput.value || nameInput.value.trim().length < 2) {
                window.ZSphereUI.showToast('Full name must be at least 2 characters', 'warning');
                return;
            }

            submitBtn.disabled = true;
            submitBtn.textContent = 'Saving Changes...';

            try {
                await window.ZSphereAuth.updateProfile({
                    full_name: nameInput.value.trim(),
                    course: courseInput.value ? courseInput.value.trim() : '',
                    semester: semInput.value ? semInput.value.trim() : ''
                });

                submitBtn.disabled = false;
                submitBtn.textContent = 'Save Profile Changes';
                window.ZSphereUI.showToast('Profile updated successfully!', 'success');
                populateSidebarUser();
            } catch (err) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Save Profile Changes';
                const msg = window.ZSphereDataService ? window.ZSphereDataService.mapError(err.message) : err.message;
                window.ZSphereUI.showToast(msg, 'error');
            }
        });

        loadProfileForm();
    }

    // 4. Account Overview Page Command Center (account.html)
    if (window.location.pathname.includes('account.html')) {
        populateSidebarUser();
        const profile = window.ZSphereAuthState ? window.ZSphereAuthState.profile : null;
        const bannerContainer = document.getElementById('account-profile-banner');

        if (bannerContainer) {
            const isComplete = window.ZSphereAuth.isProfileComplete(profile);
            if (!isComplete) {
                bannerContainer.classList.add('warning');
                bannerContainer.innerHTML = `
                    <span class="banner-icon" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg></span>
                    <div>
                        <strong>Profile Incomplete</strong>
                        <div class="text-muted text-xs mb-2">Please complete your academic details (Course and Semester) to help us personalize your experience.</div>
                        <a href="profile.html" class="btn btn-primary btn-sm">Complete Profile Now</a>
                    </div>
                `;
            }
        }
    }
});
