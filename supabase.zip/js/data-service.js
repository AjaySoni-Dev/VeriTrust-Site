/* Z Sphere - Central Supabase Data & Database Service */

(function () {
    const PUBLIC_EVENT_FIELDS = [
        'id', 'slug', 'title', 'summary', 'description', 'event_type', 'category', 'mode', 'status',
        'start_at', 'end_at', 'venue', 'registration_opens_at', 'registration_closes_at', 'capacity',
        'registered_count', 'attendance_count', 'feedback_response_count', 'feedback_summary',
        'attendance_summary_url', 'feedback_report_url', 'verification_report_url', 'cover_path',
        'learning_points', 'agenda', 'resources', 'conducted_by', 'featured', 'published_at',
        'created_at', 'updated_at'
    ].join(',');

    const AUTH_EVENT_FIELDS = `${PUBLIC_EVENT_FIELDS},registration_form_url,whatsapp_group_url`;
    window.ZSphereDataService = {

        // 1. Error Mapping Helper
        mapError: function (error) {
            if (!error) return 'An unknown error occurred.';
            const msg = typeof error === 'string' ? error : (error.message || error.details || String(error));

            if (msg.includes('AUTH_REQUIRED')) return 'Sign in before performing this action.';
            if (msg.includes('PROFILE_INCOMPLETE')) return 'Complete your profile before registering for sessions.';
            if (msg.includes('EVENT_NOT_AVAILABLE')) return 'This session is not currently available for registration.';
            if (msg.includes('EVENT_STARTED')) return 'This session has already started.';
            if (msg.includes('REGISTRATION_NOT_OPEN')) return 'Registration has not opened yet.';
            if (msg.includes('REGISTRATION_CLOSED')) return 'Registration for this session is closed.';
            if (msg.includes('EVENT_FULL')) return 'This session has reached its full capacity.';
            if (msg.includes('EVENT_NOT_FOUND')) return 'Session not found.';
            if (msg.includes('CANCELLATION_NOT_ALLOWED')) return 'Cancellation is not permitted for this session.';
            if (msg.includes('ADMIN_REQUIRED')) return 'Administrator permissions required.';
            if (msg.includes('INVALID_STATUS')) return 'Invalid status specified.';
            if (msg.includes('ATTENDANCE_TOO_EARLY')) return 'Attendance can only be marked during or after the session.';
            if (msg.includes('Invalid login credentials')) return 'Incorrect email or password.';
            if (msg.includes('Email not confirmed')) return 'Please confirm your email before signing in.';
            if (msg.includes('User already registered')) return 'An account already exists with this email address.';
            if (msg.includes('23505') || msg.includes('duplicate key')) return 'A record with this identifier or unique value already exists.';

            return msg;
        },

        // 2. Storage Public Media URL Resolver
        getPublicMediaUrl: function (path) {
            if (!path) return null;
            if (path.startsWith('http://') || path.startsWith('https://')) return path;
            if (!window.supabaseClient) return null;

            const { data } = window.supabaseClient.storage
                .from(window.ZSphereConfig.BUCKET_NAME)
                .getPublicUrl(path);

            return data ? data.publicUrl : null;
        },

        // 3. Upload Media Helper
        uploadPublicMedia: async function (file, folder, subfolder = 'general') {
            if (!window.supabaseClient) throw new Error('Database client offline');

            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/avif'];
            if (!allowedTypes.includes(file.type)) {
                throw new Error('Unsupported image format. Allowed formats: JPEG, PNG, WebP, AVIF.');
            }

            const maxSize = 8 * 1024 * 1024; // 8MB
            if (file.size > maxSize) {
                throw new Error('Image size exceeds 8 MB limit.');
            }

            const allowedFolders = ['events', 'gallery', 'team'];
            if (!allowedFolders.includes(folder)) {
                throw new Error('Invalid storage folder target.');
            }

            const ext = file.name.split('.').pop().toLowerCase() || 'jpg';
            const uuid = crypto.randomUUID ? crypto.randomUUID() : (Date.now() + Math.random().toString(36).substring(2, 8));
            const storagePath = `${folder}/${subfolder}/${uuid}.${ext}`;

            const { data, error } = await window.supabaseClient.storage
                .from(window.ZSphereConfig.BUCKET_NAME)
                .upload(storagePath, file, {
                    contentType: file.type,
                    upsert: false
                });

            if (error) throw error;
            return data.path;
        },

        // 4. PUBLIC EVENTS QUERIES
        getDefaultFeaturedEvents: function () {
            return [
                {
                    id: 'evt-ai-sprint',
                    title: 'Advanced AI & Structured Prompting Frameworks',
                    slug: 'advanced-ai-prompting-frameworks',
                    event_type: 'workshop',
                    status: 'published',
                    venue: 'Lab 402 / In-Person',
                    category: 'AI & Prompt Engineering',
                    start_at: new Date(Date.now() + 4 * 86400000).toISOString(),
                    end_at: new Date(Date.now() + 4 * 86400000 + 7200000).toISOString(),
                    summary: 'Hands-on exploration of chaining models, JSON schemas, few-shot prompting, and hallucination reduction techniques.',
                    conducted_by: 'Z Sphere Core Team',
                    capacity: 60,
                    registered_count: 38,
                    cover_path: null
                },
                {
                    id: 'evt-git-sprint',
                    title: 'Git Branching Strategies & Open Source Collaboration',
                    slug: 'git-branching-open-source',
                    event_type: 'build-sprint',
                    status: 'published',
                    venue: 'Google Meet / Online',
                    category: 'Git & Open Source',
                    start_at: new Date(Date.now() + 8 * 86400000).toISOString(),
                    end_at: new Date(Date.now() + 8 * 86400000 + 7200000).toISOString(),
                    summary: 'Practical interactive sprint covering rebasing, merge conflicts, pull request reviews, and contributing to real repositories.',
                    conducted_by: 'Z Sphere Open Source Lead',
                    capacity: 100,
                    registered_count: 74,
                    cover_path: null
                }
            ];
        },

        getFeaturedEvents: async function () {
            if (!window.supabaseClient) return this.getDefaultFeaturedEvents();

            try {
                const now = new Date().toISOString();
                const { data, error } = await window.supabaseClient
                    .from('events')
                    .select(PUBLIC_EVENT_FIELDS)
                    .in('status', ['published', 'completed', 'cancelled'])
                    .not('published_at', 'is', null)
                    .lte('published_at', now)
                    .eq('featured', true)
                    .order('start_at', { ascending: true })
                    .limit(6);

                if (error) {
                    console.warn('Error fetching featured events:', error.message);
                    return this.getDefaultFeaturedEvents();
                }

                if (data && data.length > 0) {
                    return data;
                }

                // Fallback query without featured flag
                const { data: fallback } = await window.supabaseClient
                    .from('events')
                    .select(PUBLIC_EVENT_FIELDS)
                    .in('status', ['published', 'completed', 'cancelled'])
                    .not('published_at', 'is', null)
                    .lte('published_at', now)
                    .order('start_at', { ascending: true })
                    .limit(4);

                if (fallback && fallback.length > 0) {
                    return fallback;
                }

                return this.getDefaultFeaturedEvents();
            } catch (e) {
                console.warn('Fallback to default featured events:', e);
                return this.getDefaultFeaturedEvents();
            }
        },

        getEvents: async function (filters = {}) {
            if (!window.supabaseClient) return [];

            const now = new Date().toISOString();
            let query = window.supabaseClient
                .from('events')
                .select(PUBLIC_EVENT_FIELDS)
                .in('status', ['published', 'completed', 'cancelled'])
                .not('published_at', 'is', null)
                .lte('published_at', now)
                .order('start_at', { ascending: true });

            if (filters.type && filters.type !== 'all') {
                query = query.eq('event_type', filters.type);
            }

            const { data, error } = await query;
            if (error) {
                console.error('Error fetching events list:', error.message);
                return [];
            }

            let results = data || [];

            // Perform in-memory sub-filtering for query/category/mode/status
            if (filters.status && filters.status !== 'all') {
                const currentDate = new Date();
                results = results.filter(e => {
                    if (filters.status === 'completed') return e.status === 'completed';
                    if (filters.status === 'upcoming') return e.status === 'published' && new Date(e.start_at) > currentDate;
                    if (filters.status === 'full') return e.capacity !== null && e.registered_count >= e.capacity;
                    return e.status === filters.status;
                });
            }

            if (filters.q) {
                const q = filters.q.toLowerCase().trim();
                results = results.filter(e =>
                    e.title.toLowerCase().includes(q) ||
                    (e.summary && e.summary.toLowerCase().includes(q)) ||
                    (e.category && e.category.toLowerCase().includes(q)) ||
                    (e.venue && e.venue.toLowerCase().includes(q))
                );
            }

            if (filters.category && filters.category !== 'all') {
                results = results.filter(e => e.category && e.category.toLowerCase().includes(filters.category.toLowerCase()));
            }

            if (filters.mode && filters.mode !== 'all') {
                results = results.filter(e => e.mode === filters.mode);
            }

            return results;
        },

        getPublicEventBySlug: async function (slug, includeRegistrationLinks = false) {
            if (!window.supabaseClient || !slug) return null;

            const isSignedIn = Boolean(window.ZSphereAuthState && window.ZSphereAuthState.user);
            const selectFields = includeRegistrationLinks && isSignedIn ? AUTH_EVENT_FIELDS : PUBLIC_EVENT_FIELDS;

            const { data, error } = await window.supabaseClient
                .from('events')
                .select(selectFields)
                .eq('slug', slug)
                .in('status', ['published', 'completed', 'cancelled'])
                .not('published_at', 'is', null)
                .lte('published_at', new Date().toISOString())
                .maybeSingle();

            if (error) console.error('Error fetching event by slug:', error.message);
            return data || null;
        },

        // 5. Removed EVENT AVAILABILITY & REGISTRATION RPCs

        // 6. ANNOUNCEMENTS & READ STATES
        getAnnouncements: async function () {
            if (!window.supabaseClient) return [];

            const now = new Date().toISOString();
            const { data: announcements, error } = await window.supabaseClient
                .from('announcements')
                .select('id, title, body, event_id, audience, priority, published_at, expires_at, created_at, events(title, slug)')
                .lte('published_at', now)
                .or(`expires_at.is.null,expires_at.gt.${now}`)
                .order('published_at', { ascending: false });

            if (error) {
                console.error('Error fetching announcements:', error.message);
                return [];
            }

            let readsMap = new Set();
            const user = window.ZSphereAuthState.user;
            if (user && announcements && announcements.length > 0) {
                const annIds = announcements.map(a => a.id);
                const { data: reads } = await window.supabaseClient
                    .from('announcement_reads')
                    .select('announcement_id')
                    .eq('user_id', user.id)
                    .in('announcement_id', annIds);

                if (reads) {
                    reads.forEach(r => readsMap.add(r.announcement_id));
                }
            }

            return (announcements || []).map(item => ({
                ...item,
                is_read: readsMap.has(item.id)
            }));
        },

        markAnnouncementRead: async function (announcementId) {
            const user = window.ZSphereAuthState.user;
            if (!window.supabaseClient || !user || !announcementId) return;

            const { error } = await window.supabaseClient
                .from('announcement_reads')
                .upsert({
                    announcement_id: announcementId,
                    user_id: user.id,
                    read_at: new Date().toISOString()
                }, { onConflict: 'announcement_id, user_id' });

            if (error) console.error('Error marking announcement read:', error.message);
        },

        markAnnouncementUnread: async function (announcementId) {
            const user = window.ZSphereAuthState.user;
            if (!window.supabaseClient || !user || !announcementId) return;

            const { error } = await window.supabaseClient
                .from('announcement_reads')
                .delete()
                .eq('announcement_id', announcementId)
                .eq('user_id', user.id);

            if (error) console.error('Error marking announcement unread:', error.message);
        },

        // 7. GALLERY & ALBUMS
        getDefaultAlbums: function () {
            return [
                {
                    id: 'album-ai-masterclass',
                    event_id: null,
                    slug: 'ai-prompt-engineering-masterclass',
                    title: 'AI & Prompt Engineering Masterclass',
                    cover_path: null,
                    is_published: true,
                    created_at: new Date(Date.now() - 3 * 86400000).toISOString(),
                    events: { title: 'AI & Prompt Engineering', start_at: new Date(Date.now() - 3 * 86400000).toISOString() }
                },
                {
                    id: 'album-hackathon-2026',
                    event_id: null,
                    slug: 'sprint-2026-hackathon-demos',
                    title: 'Sprint 2026 Hackathon & Project Demos',
                    cover_path: null,
                    is_published: true,
                    created_at: new Date(Date.now() - 10 * 86400000).toISOString(),
                    events: { title: 'Hackathons & Product Building', start_at: new Date(Date.now() - 10 * 86400000).toISOString() }
                },
                {
                    id: 'album-git-collab',
                    event_id: null,
                    slug: 'open-source-git-build-day',
                    title: 'Open Source Git & Team Build Day',
                    cover_path: null,
                    is_published: true,
                    created_at: new Date(Date.now() - 18 * 86400000).toISOString(),
                    events: { title: 'Git & Open Source', start_at: new Date(Date.now() - 18 * 86400000).toISOString() }
                }
            ];
        },

        getGalleryAlbums: async function () {
            if (!window.supabaseClient) return this.getDefaultAlbums();

            try {
                const { data, error } = await window.supabaseClient
                    .from('gallery_albums')
                    .select('id, event_id, slug, title, cover_path, is_published, created_at, events(title, start_at)')
                    .eq('is_published', true)
                    .order('created_at', { ascending: false });

                if (error) {
                    console.warn('Error fetching gallery albums:', error.message);
                    return this.getDefaultAlbums();
                }
                if (!data || data.length === 0) {
                    return this.getDefaultAlbums();
                }
                return data;
            } catch (e) {
                console.warn('Fallback to default albums:', e);
                return this.getDefaultAlbums();
            }
        },

        getGalleryAlbumBySlug: async function (slug) {
            if (!window.supabaseClient || !slug) return null;

            const { data, error } = await window.supabaseClient
                .from('gallery_albums')
                .select('id, event_id, slug, title, cover_path, is_published, created_at, events(title, start_at)')
                .eq('slug', slug)
                .maybeSingle();

            if (error) console.error('Error fetching album:', error.message);
            return data || null;
        },

        getGalleryAlbumByEventId: async function (eventId) {
            if (!window.supabaseClient || !eventId) return null;

            const { data, error } = await window.supabaseClient
                .from('gallery_albums')
                .select('id, event_id, slug, title, cover_path, is_published, created_at')
                .eq('event_id', eventId)
                .eq('is_published', true)
                .maybeSingle();

            if (error) console.error('Error fetching album by event ID:', error.message);
            return data || null;
        },

        getGalleryImages: async function (albumId) {
            if (!window.supabaseClient || !albumId) return [];

            const { data, error } = await window.supabaseClient
                .from('gallery_images')
                .select('id, album_id, storage_path, alt_text, caption, sort_order, is_published')
                .eq('album_id', albumId)
                .eq('is_published', true)
                .order('sort_order', { ascending: true });

            if (error) {
                console.error('Error fetching album images:', error.message);
                return [];
            }
            return data || [];
        },

        // 8. TEAM MEMBERS
        getTeamMembers: async function () {
            if (!window.supabaseClient) return [];

            const { data, error } = await window.supabaseClient
                .from('team_members')
                .select('*')
                .eq('is_active', true)
                .order('group_name', { ascending: true })
                .order('sort_order', { ascending: true });

            if (error) {
                console.error('Error fetching team members:', error.message);
                return [];
            }
            return data || [];
        },

        // 9. ADMIN OPERATIONS (EVENTS, REGISTRATIONS, ANNOUNCEMENTS, GALLERY, TEAM)
        adminGetDashboardStats: async function () {
            if (!window.supabaseClient) return { events: 0, registrations: 0, announcements: 0, albums: 0 };

            try {
                const [{ count: eventsCount }, { data: evtsData }, { count: annCount }, { count: albCount }] = await Promise.all([
                    window.supabaseClient.from('events').select('id', { count: 'exact', head: true }),
                    window.supabaseClient.from('events').select('registered_count'),
                    window.supabaseClient.from('announcements').select('id', { count: 'exact', head: true }),
                    window.supabaseClient.from('gallery_albums').select('id', { count: 'exact', head: true })
                ]);

                const regCount = evtsData ? evtsData.reduce((acc, curr) => acc + (curr.registered_count || 0), 0) : 0;

                return {
                    events: eventsCount || 0,
                    registrations: regCount || 0,
                    announcements: annCount || 0,
                    albums: albCount || 0
                };
            } catch (e) {
                console.warn('Dashboard stats load error:', e);
                return { events: 0, registrations: 0, announcements: 0, albums: 0 };
            }
        },

        adminGetEvents: async function () {
            if (!window.supabaseClient) return [];

            try {
                const { data, error } = await window.supabaseClient
                    .from('events')
                    .select('*')
                    .order('start_at', { ascending: false });

                if (error) {
                    console.warn('adminGetEvents ordered query failed, trying unordered fallback:', error.message);
                    const { data: fallback, error: fallbackError } = await window.supabaseClient
                        .from('events')
                        .select('*');
                    if (fallbackError) {
                        console.error('adminGetEvents fallback error:', fallbackError.message);
                        return [];
                    }
                    return fallback || [];
                }
                return data || [];
            } catch (e) {
                console.error('adminGetEvents exception:', e);
                return [];
            }
        },

        adminCreateEvent: async function (eventData, coverFile) {
            const user = window.ZSphereAuthState.user;
            if (!user) throw new Error('Authentication required');

            let coverPath = eventData.cover_path || null;
            if (coverFile) {
                coverPath = await this.uploadPublicMedia(coverFile, 'events', eventData.slug || 'covers');
            }

            const payload = {
                ...eventData,
                cover_path: coverPath,
                created_by: user.id
            };

            const { data, error } = await window.supabaseClient
                .from('events')
                .insert([payload])
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminUpdateEvent: async function (id, eventData, coverFile) {
            if (!id) throw new Error('Event ID required');

            let coverPath = eventData.cover_path;
            let oldCoverPath = null;
            
            if (coverFile) {
                const { data: oldEvent } = await window.supabaseClient.from('events').select('cover_path').eq('id', id).maybeSingle();
                if (oldEvent && oldEvent.cover_path) oldCoverPath = oldEvent.cover_path;
                coverPath = await this.uploadPublicMedia(coverFile, 'events', eventData.slug || 'covers');
            }

            const payload = { ...eventData };
            if (coverPath !== undefined) payload.cover_path = coverPath;

            const { data, error } = await window.supabaseClient
                .from('events')
                .update(payload)
                .eq('id', id)
                .select()
                .single();

            if (error) {
                if (coverFile && coverPath) {
                    await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([coverPath]);
                }
                throw new Error(this.mapError(error.message));
            }
            
            if (oldCoverPath) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([oldCoverPath]);
            }
            return data;
        },

        adminDeleteEvent: async function (id) {
            if (!id) throw new Error('Event ID required');

            const { data: event } = await window.supabaseClient.from('events').select('cover_path, gallery_albums(id, cover_path)').eq('id', id).maybeSingle();
            let pathsToRemove = [];
            
            if (event) {
                if (event.cover_path) pathsToRemove.push(event.cover_path);
                if (event.gallery_albums && event.gallery_albums.length > 0) {
                    const album = event.gallery_albums[0];
                    if (album.cover_path) pathsToRemove.push(album.cover_path);
                    const { data: images } = await window.supabaseClient.from('gallery_images').select('storage_path').eq('album_id', album.id);
                    if (images) {
                        images.forEach(img => {
                            if (img.storage_path) pathsToRemove.push(img.storage_path);
                        });
                    }
                }
            }

            const { error } = await window.supabaseClient
                .from('events')
                .delete()
                .eq('id', id);

            if (error) throw new Error(this.mapError(error.message));
            
            if (pathsToRemove.length > 0) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove(pathsToRemove);
            }
        },

        adminGetEventBySlug: async function (slug) {
            if (!window.supabaseClient || !slug) return null;

            const { data, error } = await window.supabaseClient
                .from('events')
                .select('*')
                .eq('slug', slug)
                .maybeSingle();

            if (error) throw new Error(this.mapError(error.message));
            return data || null;
        },

        // Removed admin registration management

        adminGetAnnouncements: async function () {
            if (!window.supabaseClient) return [];

            const { data, error } = await window.supabaseClient
                .from('announcements')
                .select('*, events(title, slug)')
                .order('created_at', { ascending: false });

            if (error) throw new Error(this.mapError(error.message));
            return data || [];
        },

        adminCreateAnnouncement: async function (announcementData) {
            const user = window.ZSphereAuthState.user;
            if (!user) throw new Error('Authentication required');

            const payload = {
                ...announcementData,
                created_by: user.id
            };

            const { data, error } = await window.supabaseClient
                .from('announcements')
                .insert([payload])
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminUpdateAnnouncement: async function (id, announcementData) {
            const { data, error } = await window.supabaseClient
                .from('announcements')
                .update(announcementData)
                .eq('id', id)
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminDeleteAnnouncement: async function (id) {
            const { error } = await window.supabaseClient
                .from('announcements')
                .delete()
                .eq('id', id);

            if (error) throw new Error(this.mapError(error.message));
        },

        adminGetAlbums: async function () {
            if (!window.supabaseClient) return [];

            const { data, error } = await window.supabaseClient
                .from('gallery_albums')
                .select('*, events(title)')
                .order('created_at', { ascending: false });

            if (error) throw new Error(this.mapError(error.message));
            return data || [];
        },

        adminCreateAlbum: async function (albumData, coverFile) {
            const user = window.ZSphereAuthState.user;
            if (!user) throw new Error('Authentication required');

            let coverPath = albumData.cover_path || null;
            if (coverFile) {
                coverPath = await this.uploadPublicMedia(coverFile, 'gallery', albumData.slug || 'covers');
            }

            const payload = {
                ...albumData,
                is_published: albumData.is_published !== undefined ? albumData.is_published : true,
                cover_path: coverPath,
                created_by: user.id
            };

            const { data, error } = await window.supabaseClient
                .from('gallery_albums')
                .insert([payload])
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminDeleteAlbum: async function (id) {
            const { data: album } = await window.supabaseClient.from('gallery_albums').select('cover_path').eq('id', id).maybeSingle();
            let pathsToRemove = [];
            
            if (album) {
                if (album.cover_path) pathsToRemove.push(album.cover_path);
                const { data: images } = await window.supabaseClient.from('gallery_images').select('storage_path').eq('album_id', id);
                if (images) {
                    images.forEach(img => {
                        if (img.storage_path) pathsToRemove.push(img.storage_path);
                    });
                }
            }

            const { error } = await window.supabaseClient
                .from('gallery_albums')
                .delete()
                .eq('id', id);

            if (error) throw new Error(this.mapError(error.message));
            
            if (pathsToRemove.length > 0) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove(pathsToRemove);
            }
        },

        adminGetAlbumImages: async function (albumId) {
            if (!window.supabaseClient || !albumId) return [];

            const { data, error } = await window.supabaseClient
                .from('gallery_images')
                .select('*')
                .eq('album_id', albumId)
                .order('sort_order', { ascending: true });

            if (error) throw new Error(this.mapError(error.message));
            return data || [];
        },

        adminCreateGalleryImage: async function (albumId, file, altText, caption, sortOrder = 0) {
            const user = window.ZSphereAuthState.user;
            if (!user) throw new Error('Authentication required');

            const storagePath = await this.uploadPublicMedia(file, 'gallery', albumId);

            const payload = {
                album_id: albumId,
                storage_path: storagePath,
                alt_text: altText,
                caption: caption,
                sort_order: parseInt(sortOrder) || 0,
                is_published: true,
                created_by: user.id
            };

            const { data, error } = await window.supabaseClient
                .from('gallery_images')
                .insert([payload])
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminDeleteGalleryImage: async function (imageId, storagePath) {
            const { error } = await window.supabaseClient
                .from('gallery_images')
                .delete()
                .eq('id', imageId);

            if (error) throw new Error(this.mapError(error.message));

            if (storagePath) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([storagePath]);
            }
        },

        adminGetTeamMembers: async function () {
            if (!window.supabaseClient) return [];

            const { data, error } = await window.supabaseClient
                .from('team_members')
                .select('*')
                .order('group_name', { ascending: true })
                .order('sort_order', { ascending: true });

            if (error) throw new Error(this.mapError(error.message));
            return data || [];
        },

        adminCreateTeamMember: async function (memberData, photoFile) {
            let photoPath = memberData.photo_path || null;
            if (photoFile) {
                photoPath = await this.uploadPublicMedia(photoFile, 'team', 'avatars');
            }

            const payload = {
                ...memberData,
                photo_path: photoPath
            };

            const { data, error } = await window.supabaseClient
                .from('team_members')
                .insert([payload])
                .select()
                .single();

            if (error) throw new Error(this.mapError(error.message));
            return data;
        },

        adminUpdateTeamMember: async function (id, memberData, photoFile) {
            let photoPath = memberData.photo_path;
            let oldPhotoPath = null;
            
            if (photoFile) {
                const { data: oldMem } = await window.supabaseClient.from('team_members').select('photo_path').eq('id', id).maybeSingle();
                if (oldMem && oldMem.photo_path) oldPhotoPath = oldMem.photo_path;
                photoPath = await this.uploadPublicMedia(photoFile, 'team', 'avatars');
            }

            const payload = { ...memberData };
            if (photoPath !== undefined) payload.photo_path = photoPath;

            const { data, error } = await window.supabaseClient
                .from('team_members')
                .update(payload)
                .eq('id', id)
                .select()
                .single();

            if (error) {
                if (photoFile && photoPath) {
                    await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([photoPath]);
                }
                throw new Error(this.mapError(error.message));
            }
            
            if (oldPhotoPath) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([oldPhotoPath]);
            }
            return data;
        },

        adminDeleteTeamMember: async function (id) {
            const { data: member } = await window.supabaseClient.from('team_members').select('photo_path').eq('id', id).maybeSingle();
            
            const { error } = await window.supabaseClient
                .from('team_members')
                .delete()
                .eq('id', id);

            if (error) throw new Error(this.mapError(error.message));
            
            if (member && member.photo_path) {
                await window.supabaseClient.storage.from(window.ZSphereConfig.BUCKET_NAME).remove([member.photo_path]);
            }
        }
    };
})();
