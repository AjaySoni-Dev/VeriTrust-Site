/* Z Sphere — Dark-only enforcement and progressive motion enhancements */
(function () {
    'use strict';

    // The product is intentionally dark-only. Remove any stale theme preference.
    document.documentElement.setAttribute('data-theme', 'dark');
    try { localStorage.removeItem('theme'); } catch (e) {}

    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function setRevealDelays(scope) {
        const root = scope || document;
        const selectors = [
            '.event-card', '.domain-card', '.album-card', '.team-card',
            '.announcement-card', '.proof-card', '.event-section', '.registration-card',
            '.admin-stat-card', '.admin-action-card', '.admin-card-section', '.admin-row-card'
        ];

        selectors.forEach((selector) => {
            const nodes = root.querySelectorAll(selector);
            nodes.forEach((node, index) => {
                if (!node.classList.contains('reveal')) node.classList.add('reveal');
                if (!node.style.getPropertyValue('--reveal-delay')) {
                    node.style.setProperty('--reveal-delay', `${Math.min(index % 6, 5) * 55}ms`);
                }
            });
        });

        if (window.ZSphereUI && typeof window.ZSphereUI.initRevealObserver === 'function') {
            window.ZSphereUI.initRevealObserver();
        }
    }

    function syncHeader() {
        const header = document.querySelector('.site-header');
        if (!header) return;
        header.classList.toggle('scrolled', window.scrollY > 12);
    }

    function initHeroPointer() {
        if (reducedMotion) return;
        const hero = document.querySelector('.hero');
        if (!hero) return;

        let raf = null;
        hero.addEventListener('pointermove', (event) => {
            if (raf) cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
                const rect = hero.getBoundingClientRect();
                const x = ((event.clientX - rect.left) / rect.width) * 100;
                const y = ((event.clientY - rect.top) / rect.height) * 100;
                hero.style.setProperty('--hero-x', `${Math.max(0, Math.min(100, x)).toFixed(1)}%`);
                hero.style.setProperty('--hero-y', `${Math.max(0, Math.min(100, y)).toFixed(1)}%`);
            });
        }, { passive: true });

        hero.addEventListener('pointerleave', () => {
            hero.style.setProperty('--hero-x', '50%');
            hero.style.setProperty('--hero-y', '0%');
        }, { passive: true });
    }

    function init() {
        // Defensive cleanup if an old cached page still contains theme controls.
        document.querySelectorAll('.theme-toggle-btn').forEach((button) => button.remove());
        setRevealDelays(document);
        syncHeader();
        initHeroPointer();

        window.addEventListener('scroll', syncHeader, { passive: true });

        if ('MutationObserver' in window) {
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node && node.nodeType === 1) setRevealDelays(node);
                    });
                });
            });
            observer.observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
