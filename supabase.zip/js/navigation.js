/* Z Sphere - Mobile Navigation & Canonical Link Synchronizer */

(function () {
    window.ZSphereNav = {
        // Canonical Public Navigation Data Source (UI-01)
        publicNavItems: [
            { label: 'Home', page: 'index2.html' },
            { label: 'Sessions', page: 'sessions.html' },
            { label: 'Learning Tracks', page: 'domains.html' },
            { label: 'Announcements', page: 'announcements.html' },
            { label: 'Gallery', page: 'gallery.html' },
            { label: 'Team', page: 'team.html' },
            { label: 'About', page: 'about.html' }
        ],

        // Active page calculation helper
        getCurrentPage: function () {
            const path = window.location.pathname;
            const filename = path.split('/').pop().split('?')[0] || 'index2.html';
            return filename;
        },

        // Compute correct relative link from current directory context
        getRelativeHref: function (targetPage) {
            const isPages = window.location.pathname.includes('/pages/');
            if (targetPage === 'index2.html') {
                return isPages ? '../index2.html' : 'index2.html';
            }
            return isPages ? targetPage : `pages/${targetPage}`;
        },

        // Synchronize desktop nav, drawer nav, and footer nav to prevent drift (UI-01, UI-02, UI-31)
        syncPublicNavigation: function () {
            const current = this.getCurrentPage();

            // Desktop Nav Sync
            const desktopNav = document.querySelector('.desktop-nav');
            if (desktopNav && !desktopNav.dataset.custom) {
                let html = '';
                this.publicNavItems.forEach(item => {
                    const href = this.getRelativeHref(item.page);
                    const active = (item.page === current || (item.page === 'domains.html' && current === 'domain.html') || (item.page === 'sessions.html' && current === 'event.html') || (item.page === 'gallery.html' && current === 'gallery-album.html')) ? 'active' : '';
                    html += `<a href="${href}" class="nav-link ${active}">${item.label}</a>`;
                });
                desktopNav.innerHTML = html;
            }

            // Drawer Nav Sync
            const drawerNav = document.querySelector('.drawer-nav');
            if (drawerNav && !drawerNav.dataset.custom) {
                let html = '';
                this.publicNavItems.forEach(item => {
                    const href = this.getRelativeHref(item.page);
                    const active = (item.page === current || (item.page === 'domains.html' && current === 'domain.html') || (item.page === 'sessions.html' && current === 'event.html') || (item.page === 'gallery.html' && current === 'gallery-album.html')) ? 'active' : '';
                    html += `<a href="${href}" class="drawer-nav-link ${active}">${item.label}</a>`;
                });
                drawerNav.innerHTML = html;
            }

            // Footer Nav Sync (Ensures public footer never exposes internal admin links - UI-31)
            const footerNav = document.querySelector('.footer-nav');
            if (footerNav && !footerNav.dataset.custom) {
                let html = '';
                this.publicNavItems.forEach(item => {
                    const href = this.getRelativeHref(item.page);
                    html += `<a href="${href}" class="footer-link">${item.label}</a>`;
                });
                footerNav.innerHTML = html;
            }
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        // Sync public navigation markup
        window.ZSphereNav.syncPublicNavigation();

        // Accessible Drawer Controller with Complete Focus Trap & Return (UI-04)
        const mobileToggle = document.querySelector('.mobile-toggle');
        const drawer = document.querySelector('.mobile-drawer');
        const backdrop = document.querySelector('.mobile-drawer-backdrop');
        const drawerClose = document.querySelector('.drawer-close');
        let focusReturnElement = null;

        if (mobileToggle) {
            mobileToggle.setAttribute('aria-expanded', 'false');
            mobileToggle.setAttribute('aria-controls', 'mobile-drawer-pane');
            mobileToggle.setAttribute('aria-label', 'Open navigation menu');
        }

        if (drawer) {
            drawer.setAttribute('id', 'mobile-drawer-pane');
        }

        function openDrawer() {
            if (drawer && backdrop) {
                focusReturnElement = document.activeElement;
                drawer.classList.add('active');
                backdrop.classList.add('active');
                document.body.style.overflow = 'hidden';
                if (mobileToggle) {
                    mobileToggle.setAttribute('aria-expanded', 'true');
                }
                const firstFocusable = drawer.querySelector('button, [href], input, select, textarea');
                if (firstFocusable) {
                    setTimeout(() => firstFocusable.focus(), 50);
                }
            }
        }

        function closeDrawer() {
            if (drawer && backdrop) {
                drawer.classList.remove('active');
                backdrop.classList.remove('active');
                document.body.style.overflow = '';
                if (mobileToggle) {
                    mobileToggle.setAttribute('aria-expanded', 'false');
                }
                if (focusReturnElement && typeof focusReturnElement.focus === 'function') {
                    focusReturnElement.focus();
                }
            }
        }

        if (mobileToggle) {
            mobileToggle.addEventListener('click', openDrawer);
        }

        if (drawerClose) {
            drawerClose.addEventListener('click', closeDrawer);
        }

        if (backdrop) {
            backdrop.addEventListener('click', closeDrawer);
        }

        // Accessible Keyboard Trap inside Drawer & ESC dismissal
        document.addEventListener('keydown', function (e) {
            if (!drawer || !drawer.classList.contains('active')) return;

            if (e.key === 'Escape') {
                closeDrawer();
            } else if (e.key === 'Tab') {
                const focusable = Array.from(drawer.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'));
                if (!focusable.length) return;

                const first = focusable[0];
                const last = focusable[focusable.length - 1];

                if (e.shiftKey && document.activeElement === first) {
                    last.focus();
                    e.preventDefault();
                } else if (!e.shiftKey && document.activeElement === last) {
                    first.focus();
                    e.preventDefault();
                }
            }
        });
    });
})();
